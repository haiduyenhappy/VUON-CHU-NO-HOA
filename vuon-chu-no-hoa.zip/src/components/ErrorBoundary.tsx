import React, { Component, ErrorInfo, ReactNode } from 'react';
import { RotateCcw, Home, AlertCircle } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallbackTitle?: string;
  onReset?: () => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
    this.setState({ error, errorInfo });
  }

  private handleReload = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
    if (this.props.onReset) {
      this.props.onReset();
    } else {
      window.location.reload();
    }
  };

  private handleGoHome = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
    try {
      localStorage.removeItem('vuonchu_auth_session');
    } catch (e) {}
    window.location.href = '/';
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-b from-sky-50 via-amber-50 to-emerald-50 text-stone-800">
          <div className="bg-white rounded-3xl border-3 border-pink-300 max-w-lg w-full p-6 sm:p-8 text-center shadow-xl space-y-4">
            <div className="w-16 h-16 sm:w-20 sm:h-20 mx-auto rounded-full bg-pink-100 border-2 border-pink-300 flex items-center justify-center text-3xl sm:text-4xl shadow-inner animate-pulse">
              🌸
            </div>

            <div className="space-y-1">
              <span className="text-xs font-black uppercase tracking-wider px-3 py-1 rounded-full bg-pink-100 text-pink-900 border border-pink-200">
                Hoa Nhỏ Đang Chăm Sóc Lại Vườn Chữ
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-purple-950 font-display mt-2">
                {this.props.fallbackTitle || 'Đã có chút gián đoạn nhỏ!'}
              </h2>
              <p className="text-xs sm:text-sm text-stone-600 font-medium leading-relaxed">
                Hoa Nhỏ đã giữ an toàn toàn bộ dữ liệu bài viết của con. Con hãy bấm nút bên dưới để khôi phục lại màn hình nhé!
              </p>
            </div>

            {/* Error detail in dev */}
            {this.state.error && (
              <div className="text-left bg-rose-50/70 p-3 rounded-2xl border border-rose-200 text-xs text-rose-900 font-mono overflow-x-auto max-h-32">
                <div className="flex items-center gap-1.5 font-bold mb-1">
                  <AlertCircle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                  <span>Chi tiết kỹ thuật:</span>
                </div>
                <p className="break-words">{this.state.error.message}</p>
              </div>
            )}

            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                onClick={this.handleReload}
                className="flex items-center gap-1.5 px-5 py-2.5 rounded-2xl bg-gradient-to-r from-pink-500 via-purple-600 to-sky-500 hover:from-pink-600 hover:to-sky-600 text-white font-black text-xs sm:text-sm shadow-md transition-all hover:scale-102 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Thử lại ngay</span>
              </button>

              <button
                onClick={this.handleGoHome}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-stone-100 hover:bg-stone-200 text-stone-700 border border-stone-300 font-bold text-xs sm:text-sm transition-colors cursor-pointer"
              >
                <Home className="w-4 h-4" />
                <span>Về trang chủ</span>
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
