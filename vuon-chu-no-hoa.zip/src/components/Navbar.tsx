import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Sparkles, Home, BookOpen, Trees, Map, Edit3, Heart, Menu, X, LogOut, Shield } from 'lucide-react';
import { AppSettings, Student, AuthUser } from '../types';
import { TEACHER_CONFIG } from '../constants/teacherConfig';

export type AppView = 
  | 'home' 
  | 'student' 
  | 'teacher' 
  | 'family' 
  | 'reading_garden' 
  | 'idea_map' 
  | 'essay_feedback'
  | 'progress_journey'
  | 'admin_system'
  | 'login-student'
  | 'login-teacher'
  | 'login-family';

interface NavbarProps {
  currentRole: AppView;
  currentUser: AuthUser | null;
  activeStudent: Student | null;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onNavigate: (view: AppView) => void;
  onLogout: () => void;
  onOpenProgressModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRole,
  currentUser,
  activeStudent,
  settings,
  onUpdateSettings,
  onNavigate,
  onLogout,
  onOpenProgressModal
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Close mobile drawer on Escape key press
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isMobileMenuOpen) {
        setIsMobileMenuOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isMobileMenuOpen]);

  const handleNav = (view: AppView) => {
    setIsMobileMenuOpen(false);
    onNavigate(view);
  };

  const handleLogoutClick = () => {
    setIsMobileMenuOpen(false);
    onLogout();
  };

  return (
    <header className="sticky top-0 z-40 bg-white/98 backdrop-blur-md border-b border-pink-200/90 shadow-xs">
      <div className="max-w-7xl mx-auto px-3 sm:px-5 lg:px-6 py-2.5">
        
        {/* DESKTOP & LAPTOP LAYOUT */}
        {/* Large screens (>= 1280px / xl): Single unified row with Group A (Left), Group B (Center), Group C (Right) */}
        {/* Medium screens (1024px - 1279px / lg): Two clean rows so no button is ever cramped or word-wrapped awkwardly */}
        <div className="hidden lg:flex xl:flex-row flex-col xl:items-center xl:justify-between gap-2.5">
          
          {/* Top row on lg / Left side on xl: NHÓM A - NHẬN DIỆN & NHÓM C - TIỆN ÍCH TRÊN LG */}
          <div className="flex items-center justify-between gap-4 w-full xl:w-auto shrink-0">
            {/* NHÓM A – NHẬN DIỆN ỨNG DỤNG (Bên trái) */}
            <div 
              onClick={() => handleNav('home')} 
              className="flex items-center gap-3 cursor-pointer group shrink-0"
              title="Về Trang chủ Vườn Chữ Nở Hoa"
              role="button"
              tabIndex={0}
              onKeyDown={(e) => { if (e.key === 'Enter') handleNav('home'); }}
            >
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-pink-400 via-purple-400 to-sky-400 p-0.5 shadow-sm group-hover:rotate-6 transition-transform shrink-0 flex items-center justify-center">
                <div className="w-full h-full bg-white rounded-[14px] flex items-center justify-center text-2xl select-none">
                  🌸
                </div>
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="font-black text-base sm:text-lg lg:text-xl text-purple-950 tracking-tight font-display whitespace-nowrap">
                    Trợ Lí Tập Làm Văn AI
                  </h1>
                  <span className="hidden sm:inline-flex text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-pink-100 text-pink-900 border border-pink-200 whitespace-nowrap shadow-2xs">
                    Vườn Chữ Nở Hoa – Cùng Em Viết Văn Sáng Tạo
                  </span>
                </div>
                <p className="text-[11px] text-purple-800/80 font-semibold hidden md:block whitespace-normal leading-snug">
                  Mỗi em một ý tưởng – Mỗi bài viết một sắc màu
                </p>
              </div>
            </div>

            {/* Trên màn hình laptop (lg), hiển thị Nhóm C ở góc phải hàng 1 để cân đối */}
            <div className="flex xl:hidden items-center gap-2 shrink-0">
              {/* Sound Toggle */}
              <button
                onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
                className={`h-10 w-10 rounded-2xl border transition-all flex items-center justify-center cursor-pointer ${
                  settings.soundEnabled
                    ? 'bg-pink-100 text-pink-900 border-pink-300 hover:bg-pink-200 shadow-2xs'
                    : 'bg-stone-100 text-stone-500 border-stone-200 hover:bg-stone-200'
                }`}
                title={settings.soundEnabled ? 'Âm thanh: Đang BẬT' : 'Âm thanh: Đang TẮT'}
                aria-label="Bật tắt âm thanh"
              >
                {settings.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </button>

              {/* Reduced Motion Toggle */}
              <button
                onClick={() => onUpdateSettings({ reducedMotion: !settings.reducedMotion })}
                className={`h-10 w-10 rounded-2xl border transition-all flex items-center justify-center cursor-pointer ${
                  settings.reducedMotion
                    ? 'bg-purple-100 text-purple-900 border-purple-300 hover:bg-purple-200 shadow-2xs'
                    : 'bg-stone-100 text-stone-500 border-stone-200 hover:bg-stone-200'
                }`}
                title={settings.reducedMotion ? 'Chuyển động: Đã giảm' : 'Chuyển động: Sinh động'}
                aria-label="Giảm hiệu ứng chuyển động"
              >
                <Sparkles className="w-4 h-4" />
              </button>

              {/* User session status badge & actions */}
              {currentUser ? (
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-2xl text-xs font-bold bg-purple-50 text-purple-950 border border-purple-200 whitespace-nowrap shadow-2xs">
                    {currentUser.role === 'teacher' ? (
                      <span className="text-amber-900 font-extrabold flex items-center gap-1">
                        👑 Quản trị: Cô Nguyễn Thị Hải Duyên
                      </span>
                    ) : currentUser.role === 'student' ? (
                      <span className="text-purple-950 font-bold flex items-center gap-1">
                        {activeStudent?.avatar || '🎒'} HS: {activeStudent?.name || 'Học sinh'}
                      </span>
                    ) : (
                      <span className="text-rose-950 font-bold flex items-center gap-1">
                        🏡 PH: {currentUser.parentName || currentUser.caregiver?.name || (activeStudent ? `Phụ huynh em ${activeStudent.name}` : 'Gia đình')}
                      </span>
                    )}
                  </div>

                  {currentUser.teacherRole === 'SUPER_ADMIN' && (
                    <button
                      onClick={() => onNavigate(currentRole === 'admin_system' ? 'teacher' : 'admin_system')}
                      className="min-h-[40px] px-3.5 py-1.5 rounded-2xl text-xs font-black bg-amber-100 hover:bg-amber-200 text-amber-950 border border-amber-300 transition-all cursor-pointer whitespace-nowrap shadow-xs"
                      title="Chuyển đổi giữa Trang Quản trị hệ thống và Lớp học của tôi"
                    >
                      {currentRole === 'admin_system' ? '👩‍🏫 Về lớp tôi' : '👑 Quản trị HT'}
                    </button>
                  )}

                  <button
                    onClick={onLogout}
                    className="min-h-[40px] px-3.5 py-1.5 rounded-2xl text-xs font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 transition-all whitespace-nowrap cursor-pointer shadow-2xs"
                    title="Đăng xuất khỏi phiên làm việc"
                  >
                    <span>Đăng xuất</span>
                  </button>
                </div>
              ) : (
                currentRole !== 'home' && (
                  <button
                    onClick={onLogout}
                    className="min-h-[40px] flex items-center gap-1.5 px-4 py-1.5 rounded-2xl text-xs font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition-all cursor-pointer shadow-2xs"
                    title="Về Cổng chính Vườn Chữ Nở Hoa"
                  >
                    <Home className="w-4 h-4" />
                    <span>Trang chủ</span>
                  </button>
                )
              )}
            </div>
          </div>

          {/* NHÓM B – MENU CHỨC NĂNG (Khu vực giữa trên Desktop rộng, hàng riêng căn giữa trên Laptop) */}
          <nav 
            className="flex items-center justify-center gap-2 sm:gap-2.5 py-1 flex-wrap shrink-0"
            role="navigation"
            aria-label="Menu chức năng chính"
          >
            {/* 1. Bản đồ ý tưởng */}
            <button
              onClick={() => onNavigate('idea_map')}
              className={`h-10 min-h-[40px] px-4 py-2 rounded-2xl text-sm font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
                currentRole === 'idea_map'
                  ? 'bg-purple-600 text-white shadow-sm ring-2 ring-purple-300 font-extrabold'
                  : 'bg-purple-50 text-purple-950 hover:bg-purple-100/90 border border-purple-200 shadow-2xs hover:shadow-xs'
              }`}
              title="Trang 1: Bản đồ ý tưởng - Khơi nguồn ý tưởng và lập dàn ý"
            >
              <Map className="w-4 h-4 shrink-0 text-purple-600 group-hover:text-purple-800" />
              <span>Bản đồ ý tưởng</span>
            </button>

            {/* 2. Cô góp ý bài văn */}
            <button
              onClick={() => onNavigate('essay_feedback')}
              className={`h-10 min-h-[40px] px-4 py-2 rounded-2xl text-sm font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
                currentRole === 'essay_feedback'
                  ? 'bg-pink-600 text-white shadow-sm ring-2 ring-pink-300 font-extrabold'
                  : 'bg-pink-50 text-pink-950 hover:bg-pink-100/90 border border-pink-200 shadow-2xs hover:shadow-xs'
              }`}
              title="Trang 2: Cô góp ý bài văn - Đọc chữ viết tay, nhận xét và trao đổi"
            >
              <Edit3 className="w-4 h-4 shrink-0 text-pink-600" />
              <span>Cô góp ý bài văn</span>
            </button>

            {/* 3. Thư viện bài đọc */}
            <button
              onClick={() => onNavigate('reading_garden')}
              className={`h-10 min-h-[40px] px-4 py-2 rounded-2xl text-sm font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
                currentRole === 'reading_garden'
                  ? 'bg-sky-600 text-white shadow-sm ring-2 ring-sky-300 font-extrabold'
                  : 'bg-sky-50 text-sky-950 hover:bg-sky-100/90 border border-sky-200 shadow-2xs hover:shadow-xs'
              }`}
              title="Thư viện bài đọc thú vị & bài văn mẫu tham khảo"
            >
              <BookOpen className="w-4 h-4 shrink-0 text-sky-600" />
              <span>Thư viện bài đọc</span>
            </button>

            {/* 4. Tiến bộ */}
            {activeStudent && (
              <button
                onClick={onOpenProgressModal}
                className={`h-10 min-h-[40px] px-4 py-2 rounded-2xl text-sm font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
                  currentRole === 'progress_journey'
                    ? 'bg-emerald-600 text-white shadow-sm ring-2 ring-emerald-300 font-extrabold'
                    : 'bg-emerald-50 text-emerald-950 hover:bg-emerald-100/90 border border-emerald-200 shadow-2xs hover:shadow-xs'
                }`}
                title="Xem cây hoa và tiến bộ rèn luyện viết của em"
              >
                <Trees className="w-4 h-4 shrink-0 text-emerald-600" />
                <span>Tiến bộ</span>
                <span className="text-xs bg-emerald-600 text-white px-2 py-0.5 rounded-full font-black shadow-2xs">
                  {activeStudent.flowersEarned} 🌸
                </span>
              </button>
            )}
          </nav>

          {/* NHÓM C – TIỆN ÍCH VÀ TÀI KHOẢN (Hiển thị góc phải trên XL rộng) */}
          <div className="hidden xl:flex items-center gap-2 shrink-0">
            {/* Sound Toggle */}
            <button
              onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
              className={`h-10 w-10 rounded-2xl border transition-all flex items-center justify-center cursor-pointer ${
                settings.soundEnabled
                  ? 'bg-pink-100 text-pink-900 border-pink-300 hover:bg-pink-200 shadow-2xs'
                  : 'bg-stone-100 text-stone-500 border-stone-200 hover:bg-stone-200'
              }`}
              title={settings.soundEnabled ? 'Âm thanh: Đang BẬT' : 'Âm thanh: Đang TẮT'}
              aria-label="Bật tắt âm thanh"
            >
              {settings.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Reduced Motion Toggle */}
            <button
              onClick={() => onUpdateSettings({ reducedMotion: !settings.reducedMotion })}
              className={`h-10 w-10 rounded-2xl border transition-all flex items-center justify-center cursor-pointer ${
                settings.reducedMotion
                  ? 'bg-purple-100 text-purple-900 border-purple-300 hover:bg-purple-200 shadow-2xs'
                  : 'bg-stone-100 text-stone-500 border-stone-200 hover:bg-stone-200'
              }`}
              title={settings.reducedMotion ? 'Chuyển động: Đã giảm' : 'Chuyển động: Sinh động'}
              aria-label="Giảm hiệu ứng chuyển động"
            >
              <Sparkles className="w-4 h-4" />
            </button>

            {/* User session status badge and Actions */}
            {currentUser ? (
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-2xl text-xs sm:text-sm font-bold bg-purple-50 text-purple-950 border border-purple-200 whitespace-nowrap shadow-2xs">
                  {currentUser.role === 'teacher' ? (
                    <span className="text-amber-900 font-extrabold flex items-center gap-1">
                      👑 Quản trị: Cô Nguyễn Thị Hải Duyên
                    </span>
                  ) : currentUser.role === 'student' ? (
                    <span className="text-purple-950 font-bold flex items-center gap-1">
                      {activeStudent?.avatar || '🎒'} HS: {activeStudent?.name || 'Học sinh'}
                    </span>
                  ) : (
                    <span className="text-rose-950 font-bold flex items-center gap-1">
                      🏡 PH: {currentUser.parentName || currentUser.caregiver?.name || (activeStudent ? `Phụ huynh em ${activeStudent.name}` : 'Gia đình')}
                    </span>
                  )}
                </div>

                {currentUser.teacherRole === 'SUPER_ADMIN' && (
                  <button
                    onClick={() => onNavigate(currentRole === 'admin_system' ? 'teacher' : 'admin_system')}
                    className="h-10 min-h-[40px] px-3.5 py-2 rounded-2xl text-xs sm:text-sm font-black bg-amber-100 hover:bg-amber-200 text-amber-950 border border-amber-300 transition-all cursor-pointer whitespace-nowrap shadow-xs"
                    title="Chuyển đổi giữa Trang Quản trị hệ thống và Lớp học của tôi"
                  >
                    {currentRole === 'admin_system' ? '👩‍🏫 Về lớp tôi' : '👑 Quản trị HT'}
                  </button>
                )}

                <button
                  onClick={onLogout}
                  className="h-10 min-h-[40px] px-3.5 py-2 rounded-2xl text-xs sm:text-sm font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 transition-all whitespace-nowrap cursor-pointer shadow-2xs"
                  title="Đăng xuất khỏi phiên làm việc"
                >
                  <span>Đăng xuất</span>
                </button>
              </div>
            ) : (
              currentRole !== 'home' && (
                <button
                  onClick={onLogout}
                  className="h-10 min-h-[40px] flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition-all cursor-pointer shadow-2xs"
                  title="Về Cổng chính Vườn Chữ Nở Hoa"
                >
                  <Home className="w-4 h-4" />
                  <span>Trang chủ</span>
                </button>
              )
            )}
          </div>

        </div>

        {/* MOBILE & TABLET TOP BAR (< lg / < 1024px) */}
        <div className="flex lg:hidden items-center justify-between gap-2">
          {/* Logo and App Title */}
          <div 
            onClick={() => handleNav('home')} 
            className="flex items-center gap-2.5 cursor-pointer min-w-0"
            title="Về Trang chủ"
            role="button"
            tabIndex={0}
          >
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-pink-400 via-purple-400 to-sky-400 p-0.5 shadow-sm shrink-0 flex items-center justify-center">
              <div className="w-full h-full bg-white rounded-[14px] flex items-center justify-center text-xl select-none">
                🌸
              </div>
            </div>
            <div className="min-w-0">
              <h1 className="font-black text-base text-purple-950 font-display truncate">
                Trợ Lí Tập Làm Văn AI
              </h1>
              <p className="text-[10px] text-pink-700 font-bold truncate">
                Vườn Chữ Nở Hoa – Lớp 3
              </p>
            </div>
          </div>

          {/* Quick Audio & Hamburger Button */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Quick Sound Toggle on Mobile */}
            <button
              onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
              className={`h-11 w-11 flex items-center justify-center rounded-2xl border transition-colors ${
                settings.soundEnabled
                  ? 'bg-pink-100 text-pink-900 border-pink-300 shadow-2xs'
                  : 'bg-stone-100 text-stone-500 border-stone-200'
              }`}
              title={settings.soundEnabled ? 'Âm thanh: Đang BẬT' : 'Âm thanh: Đang TẮT'}
              aria-label="Bật tắt âm thanh"
            >
              {settings.soundEnabled ? <Volume2 className="w-5 h-5 text-pink-600" /> : <VolumeX className="w-5 h-5 text-stone-500" />}
            </button>

            {/* Mobile Hamburger Menu Toggle Button (>= 44px) */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="h-11 w-11 flex items-center justify-center rounded-2xl border-2 border-purple-300 bg-purple-50 text-purple-950 hover:bg-purple-100 active:scale-95 transition-all shadow-2xs cursor-pointer"
              aria-expanded={isMobileMenuOpen}
              aria-label={isMobileMenuOpen ? 'Đóng menu điều hướng' : 'Mở menu điều hướng'}
              title="Menu điều hướng"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6 text-purple-950" /> : <Menu className="w-6 h-6 text-purple-950" />}
            </button>
          </div>
        </div>

      </div>

      {/* MOBILE DRAWER NAVIGATION MENU (< lg) */}
      {isMobileMenuOpen && (
        <div 
          className="lg:hidden border-t-2 border-pink-200 bg-white/98 backdrop-blur-md px-4 py-4 space-y-4 shadow-xl animate-fade-in max-h-[calc(100vh-70px)] overflow-y-auto"
          role="dialog"
          aria-label="Menu chức năng di động"
        >
          {/* User Profile Card on Mobile - Hiển thị ĐẦY ĐỦ tên cô Duyên, KHÔNG CẮT CHỮ */}
          {currentUser ? (
            <div className="p-4 bg-gradient-to-r from-purple-50 via-pink-50 to-amber-50 rounded-2xl border-2 border-purple-200 space-y-2 shadow-2xs">
              <div className="flex items-start gap-3">
                <span className="text-3xl shrink-0 mt-0.5">
                  {currentUser.role === 'student' ? (activeStudent?.avatar || '🎒') : currentUser.role === 'teacher' ? '👩‍🏫' : '🏡'}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-bold text-stone-500 uppercase tracking-wider">
                    {currentUser.role === 'student' ? 'Học sinh tiểu học' : currentUser.role === 'teacher' ? (currentUser.teacherRole === 'SUPER_ADMIN' ? '👑 Quản trị viên hệ thống' : 'Giáo viên chủ nhiệm') : 'Phụ huynh học sinh'}
                  </div>
                  <div className="font-black text-base text-purple-950 leading-snug break-words">
                    {currentUser.role === 'student' && (activeStudent?.name || 'Học sinh')}
                    {currentUser.role === 'teacher' && (
                      <span className="text-amber-950">
                        Quản trị: Cô Nguyễn Thị Hải Duyên
                      </span>
                    )}
                    {currentUser.role === 'family' && (currentUser.parentName || currentUser.caregiver?.name || (activeStudent ? `Phụ huynh em ${activeStudent.name}` : 'Phụ huynh'))}
                  </div>
                  <div className="text-xs text-stone-600 font-medium mt-0.5">
                    {TEACHER_CONFIG.school}
                  </div>
                </div>

                {activeStudent && (
                  <div className="shrink-0 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300 text-xs font-black shadow-2xs">
                    {activeStudent.flowersEarned} 🌸
                  </div>
                )}
              </div>

              {/* Super Admin Quick Button on Mobile */}
              {currentUser?.teacherRole === 'SUPER_ADMIN' && (
                <div className="pt-2 border-t border-purple-100">
                  <button
                    onClick={() => handleNav(currentRole === 'admin_system' ? 'teacher' : 'admin_system')}
                    className="w-full min-h-[44px] px-4 py-2.5 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 bg-amber-100 text-amber-950 border border-amber-300 shadow-2xs"
                  >
                    <Shield className="w-4 h-4 text-amber-800" />
                    <span>{currentRole === 'admin_system' ? '👩‍🏫 Về góc lớp học của tôi' : '👑 Mở Trang Quản trị hệ thống'}</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="p-3.5 bg-pink-50/80 rounded-2xl border border-pink-200 text-xs text-pink-950 font-bold flex items-center gap-2">
              <span>🌸</span>
              <span>Vườn Chữ Nở Hoa – Cùng Em Viết Văn Sáng Tạo</span>
            </div>
          )}

          {/* Navigation Links - Minimum 44px height for touch ergonomics */}
          <div className="space-y-2">
            <button
              onClick={() => handleNav('home')}
              className={`w-full min-h-[46px] px-4 py-3 rounded-2xl font-bold text-sm flex items-center gap-3 transition-colors ${
                currentRole === 'home'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'bg-stone-50 text-stone-850 hover:bg-stone-100 border border-stone-200'
              }`}
            >
              <Home className="w-5 h-5 text-purple-600" />
              <div className="text-left">
                <div className="font-extrabold">Trang chủ Vườn Chữ</div>
                <div className="text-[11px] font-normal text-stone-500">Cổng chính 3 lối vào</div>
              </div>
            </button>

            <button
              onClick={() => handleNav('idea_map')}
              className={`w-full min-h-[46px] px-4 py-3 rounded-2xl font-bold text-sm flex items-center gap-3 transition-colors ${
                currentRole === 'idea_map'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'bg-purple-50/60 text-purple-950 hover:bg-purple-100 border border-purple-200'
              }`}
            >
              <Map className="w-5 h-5 text-purple-600" />
              <div className="text-left">
                <div className="font-extrabold">Bản đồ ý tưởng</div>
                <div className="text-[11px] font-normal text-stone-500">Trang 1 • Khơi nguồn ý tưởng và lập dàn ý</div>
              </div>
            </button>

            <button
              onClick={() => handleNav('essay_feedback')}
              className={`w-full min-h-[46px] px-4 py-3 rounded-2xl font-bold text-sm flex items-center gap-3 transition-colors ${
                currentRole === 'essay_feedback'
                  ? 'bg-pink-600 text-white shadow-sm'
                  : 'bg-pink-50/60 text-pink-950 hover:bg-pink-100 border border-pink-200'
              }`}
            >
              <Edit3 className="w-5 h-5 text-pink-600" />
              <div className="text-left">
                <div className="font-extrabold">Cô góp ý bài văn</div>
                <div className="text-[11px] font-normal text-stone-500">Trang 2 • Đọc chữ viết tay, nhận xét và trao đổi</div>
              </div>
            </button>

            <button
              onClick={() => handleNav('reading_garden')}
              className={`w-full min-h-[46px] px-4 py-3 rounded-2xl font-bold text-sm flex items-center gap-3 transition-colors ${
                currentRole === 'reading_garden'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'bg-sky-50/60 text-sky-950 hover:bg-sky-100 border border-sky-200'
              }`}
            >
              <BookOpen className="w-5 h-5 text-sky-600" />
              <div className="text-left">
                <div className="font-extrabold">Thư viện bài đọc</div>
                <div className="text-[11px] font-normal text-stone-500">Bài văn mẫu & bài đọc tham khảo lớp 3</div>
              </div>
            </button>

            {activeStudent && (
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onOpenProgressModal?.();
                }}
                className="w-full min-h-[46px] px-4 py-3 rounded-2xl font-bold text-sm flex items-center justify-between bg-emerald-50 text-emerald-950 border border-emerald-200"
              >
                <div className="flex items-center gap-3">
                  <Trees className="w-5 h-5 text-emerald-600" />
                  <div className="text-left">
                    <div className="font-extrabold">Tiến bộ của con</div>
                    <div className="text-[11px] font-normal text-stone-500">Cây hoa chữ và nhật ký bài viết</div>
                  </div>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-600 text-white text-xs font-black">
                  {activeStudent.flowersEarned} 🌸
                </span>
              </button>
            )}
          </div>

          {/* Quick Accessibility Settings on Mobile */}
          <div className="pt-2 border-t border-stone-100 flex items-center justify-between gap-2">
            <button
              onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
              className={`flex-1 min-h-[44px] px-3 py-2.5 rounded-2xl border text-xs font-bold flex items-center justify-center gap-2 ${
                settings.soundEnabled
                  ? 'bg-pink-100 text-pink-900 border-pink-300'
                  : 'bg-stone-100 text-stone-600 border-stone-200'
              }`}
            >
              {settings.soundEnabled ? <Volume2 className="w-4 h-4 text-pink-600" /> : <VolumeX className="w-4 h-4 text-stone-500" />}
              <span>{settings.soundEnabled ? 'Âm thanh: Bật' : 'Âm thanh: Tắt'}</span>
            </button>

            <button
              onClick={() => onUpdateSettings({ reducedMotion: !settings.reducedMotion })}
              className={`flex-1 min-h-[44px] px-3 py-2.5 rounded-2xl border text-xs font-bold flex items-center justify-center gap-2 ${
                settings.reducedMotion
                  ? 'bg-purple-100 text-purple-900 border-purple-300'
                  : 'bg-stone-100 text-stone-600 border-stone-200'
              }`}
            >
              <Sparkles className="w-4 h-4 text-purple-600" />
              <span>{settings.reducedMotion ? 'Chuyển động: Giảm' : 'Chuyển động: Sinh động'}</span>
            </button>
          </div>

          {/* Logout / Return Home Action Button on Mobile */}
          <div className="pt-2 border-t border-stone-100">
            {currentUser ? (
              <button
                onClick={handleLogoutClick}
                className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl bg-rose-50 hover:bg-rose-100 text-rose-800 border-2 border-rose-300 font-black text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <LogOut className="w-4 h-4 text-rose-600" />
                <span>Đăng xuất khỏi phiên làm việc</span>
              </button>
            ) : (
              currentRole !== 'home' && (
                <button
                  onClick={handleLogoutClick}
                  className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl bg-stone-100 hover:bg-stone-200 text-stone-800 border border-stone-300 font-bold text-sm flex items-center justify-center gap-2"
                >
                  <Home className="w-4 h-4" />
                  <span>Về Trang chủ Vườn Chữ</span>
                </button>
              )
            )}
          </div>
        </div>
      )}
    </header>
  );
};
